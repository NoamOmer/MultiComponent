multiT2
=======

MATLAB code for multi-component T2 estimation, together with performance evaluating scripts.

All code will be made available before publication of the corresponding paper.
